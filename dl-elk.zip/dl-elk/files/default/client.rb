log_level        :info
log_location     STDOUT
chef_server_url  'https://localhost:443'
validation_client_name 'chef-validator'
